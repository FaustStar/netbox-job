# Security Policy

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| > 2.0   | :white_check_mark: |
| < 2.0   | :x:                |

## Reporting a Vulnerability

Please create an issue when you encounter a Security issue.
